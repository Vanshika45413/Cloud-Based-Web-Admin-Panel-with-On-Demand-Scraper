
export interface ScrapedItem {
  id: string;
  title: string;
  author: string;
  description: string;
  year: number;
}

export interface User {
  email: string;
  name: string;
}

export interface SortConfig {
  key: keyof ScrapedItem | null;
  direction: 'ascending' | 'descending';
}

// For Gemini API response handling (specifically for grounding metadata)
export interface GroundingChunkWeb {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  web?: GroundingChunkWeb;
  // Other types of chunks can be added here if needed
}

export interface GroundingMetadata {
  groundingChunks?: GroundingChunk[];
  // Other grounding metadata fields can be added
}

export interface Candidate {
  groundingMetadata?: GroundingMetadata;
  // Other candidate fields
}
