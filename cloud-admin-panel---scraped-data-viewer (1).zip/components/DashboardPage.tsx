
import React, { useState, useCallback, useEffect } from 'react';
import DataTable from './DataTable';
import Button from './Button';
import LoadingSpinner from './LoadingSpinner';
import type { ScrapedItem } from '../types';
import { fetchScrapedData } from '../services/geminiService';

const DashboardPage: React.FC = () => {
  const [scrapedData, setScrapedData] = useState<ScrapedItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [lastScraped, setLastScraped] = useState<Date | null>(null);

  const handleScrapeData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await fetchScrapedData();
      setScrapedData(data);
      setLastScraped(new Date());
    } catch (err: unknown) {
      if (err instanceof Error) {
        type PotentialApiError = Error & {
          statusInfo?: { statusCode?: number | string };
          isGoogleGenAIError?: boolean; 
        };
        
        const apiError = err as PotentialApiError;

        if (apiError.isGoogleGenAIError === true) {
          let errorMessage = `Gemini API Error: ${apiError.message}`;
          if (apiError.statusInfo?.statusCode) {
            errorMessage += ` (Status: ${apiError.statusInfo.statusCode})`;
          }
          setError(errorMessage);
        } else {
          setError(`Failed to scrape data: ${apiError.message}`);
        }
      } else {
        setError('An unknown error occurred while scraping data.');
      }
      setScrapedData([]); 
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  // Optionally call on mount if desired (e.g. for initial data load, currently commented out)
  // useEffect(() => {
  //   handleScrapeData();
  // }, [handleScrapeData]);


  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8">
      <div className="bg-white shadow-xl rounded-xl p-6 md:p-8">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8 border-b border-slate-200 pb-6">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-800 mb-4 md:mb-0">Data Dashboard</h1>
          <div className="flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-4">
            {lastScraped && (
              <p className="text-sm text-slate-500 order-2 sm:order-1">
                Last updated: {lastScraped.toLocaleTimeString()} on {lastScraped.toLocaleDateString()}
              </p>
            )}
            <Button 
              onClick={handleScrapeData} 
              disabled={isLoading} 
              variant="primary" 
              size="md"
              className="order-1 sm:order-2 w-full sm:w-auto"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <LoadingSpinner size="sm" color="text-white" />
                  <span className="ml-2">Scraping...</span>
                </div>
              ) : (
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 00-15.357-2m15.357 2H15" />
                  </svg>
                  Scrape New Data
                </div>
              )}
            </Button>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-700 border border-red-200 rounded-lg flex items-start">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div>
              <p className="font-semibold text-red-800">An Error Occurred:</p>
              <p className="text-sm">{error}</p>
            </div>
          </div>
        )}

        {isLoading && scrapedData.length === 0 && (
           <div className="text-center py-16">
             <LoadingSpinner size="lg" color="text-sky-600" />
             <p className="mt-4 text-lg font-medium text-slate-600">Fetching fresh data...</p>
             <p className="text-sm text-slate-500">This might take a moment.</p>
           </div>
        )}
        
        {!isLoading && !error && scrapedData.length === 0 && (
           <div className="text-center py-16">
             <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-16 w-16 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
               <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h15.75c.621 0 1.125.504 1.125 1.125v6.75c0 .621-.504 1.125-1.125 1.125H4.125c-.621 0-1.125-.504-1.125-1.125v-6.75z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125V9.75a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 9.75v3.375m-13.5 6.188v-.018a2.25 2.25 0 013.483-2.036l.036.035a2.25 2.25 0 012.036-3.483V19.5m-9.75-3.375H7.5M10.5 19.5H15" />
             </svg>
             <h3 className="mt-4 text-xl font-semibold text-slate-800">No Data Yet</h3>
             <p className="mt-2 text-sm text-slate-500">
               Click the "Scrape New Data" button to fetch and display information.
             </p>
           </div>
        )}
        
        {scrapedData.length > 0 && (
          <DataTable data={scrapedData} />
        )}

      </div>
    </div>
  );
};

export default DashboardPage;