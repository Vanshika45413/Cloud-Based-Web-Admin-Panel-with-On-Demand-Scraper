
import React from 'react';
import Button from './Button';

interface PaginationProps {
  currentPage: number;
  totalItems: number;
  itemsPerPage: number;
  onPageChange: (page: number) => void;
}

const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalItems,
  itemsPerPage,
  onPageChange,
}) => {
  const totalPages = Math.ceil(totalItems / itemsPerPage);

  if (totalPages <= 1) {
    return null;
  }

  const handlePrevious = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };

  let pageNumbers: (number | string)[] = [];
  const maxPagesToShow = 7; // Includes current, ellipsis, first/last

  if (totalPages <= maxPagesToShow) {
    pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);
  } else {
    pageNumbers.push(1); // Always show first page

    const leftEllipsisNeeded = currentPage > 4;
    const rightEllipsisNeeded = currentPage < totalPages - 3;

    if (leftEllipsisNeeded) {
      pageNumbers.push('...');
    }

    let startPage: number, endPage: number;

    if (!leftEllipsisNeeded && rightEllipsisNeeded) { // e.g. 1 2 3 4 ... 10
      startPage = 2;
      endPage = 4;
    } else if (leftEllipsisNeeded && !rightEllipsisNeeded) { // e.g. 1 ... 7 8 9 10
      startPage = totalPages - 3;
      endPage = totalPages - 1;
    } else if (leftEllipsisNeeded && rightEllipsisNeeded) { // e.g. 1 ... 4 5 6 ... 10
      startPage = currentPage - 1;
      endPage = currentPage + 1;
    } else { // Should not happen if totalPages > maxPagesToShow
      startPage = 2;
      endPage = totalPages - 1;
    }
    
    for (let i = startPage; i <= endPage; i++) {
        if (i > 1 && i < totalPages) { // Ensure we don't duplicate first/last if they fall in range
            pageNumbers.push(i);
        }
    }


    if (rightEllipsisNeeded) {
      pageNumbers.push('...');
    }
    
    pageNumbers.push(totalPages); // Always show last page
  }
  // Remove duplicate ellipsis if any (e.g., if start/end pages are too close to 1 or totalPages)
  pageNumbers = pageNumbers.filter((item, index, self) => item !== '...' || self[index-1] !== '...');


  return (
    <div className="flex items-center justify-between border-t border-slate-200 bg-white px-4 py-3 sm:px-6 rounded-b-lg">
      {/* Mobile Pagination */}
      <div className="flex flex-1 justify-between sm:hidden">
        <Button onClick={handlePrevious} disabled={currentPage === 1} variant="outline" size="md">
          Previous
        </Button>
        <Button onClick={handleNext} disabled={currentPage === totalPages} variant="outline" size="md">
          Next
        </Button>
      </div>

      {/* Desktop Pagination */}
      <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
        <div>
          <p className="text-sm text-slate-700">
            Showing <span className="font-semibold">{(currentPage - 1) * itemsPerPage + 1}</span> to{' '}
            <span className="font-semibold">{Math.min(currentPage * itemsPerPage, totalItems)}</span> of{' '}
            <span className="font-semibold">{totalItems}</span> results
          </p>
        </div>
        <div>
          <nav className="relative z-0 inline-flex rounded-lg shadow-sm -space-x-px" aria-label="Pagination">
            <Button
              onClick={handlePrevious}
              disabled={currentPage === 1}
              variant="outline"
              size="md"
              className="relative inline-flex items-center px-2 py-2 rounded-l-lg focus:z-10"
              aria-label="Previous"
            >
              <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </Button>
            {pageNumbers.map((page, index) =>
              typeof page === 'number' ? (
                <Button
                  key={index}
                  onClick={() => onPageChange(page)}
                  variant={currentPage === page ? 'primary' : 'outline'}
                  size="md"
                  className={`relative inline-flex items-center px-4 py-2 text-sm ${
                    currentPage === page ? 'z-20' : 'focus:z-10' 
                  } ${pageNumbers[index-1] === '...' ? '' : ''} ${pageNumbers[index+1] === '...' ? '' : ''}`}
                  aria-current={currentPage === page ? 'page' : undefined}
                >
                  {page}
                </Button>
              ) : (
                <span key={index} className="relative inline-flex items-center px-4 py-2 border border-slate-300 bg-white text-sm font-medium text-slate-700">
                  {page}
                </span>
              )
            )}
            <Button
              onClick={handleNext}
              disabled={currentPage === totalPages}
              variant="outline"
              size="md"
              className="relative inline-flex items-center px-2 py-2 rounded-r-lg focus:z-10"
              aria-label="Next"
            >
              <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
              </svg>
            </Button>
          </nav>
        </div>
      </div>
    </div>
  );
};

export default Pagination;