
import React from 'react';
import type { SortConfig } from '../types';

interface SortableTableHeaderProps<T> {
  columnKey: keyof T;
  title: string;
  currentSortConfig: SortConfig;
  onSort: (key: keyof T) => void;
  className?: string;
}

const SortableTableHeader = <T,>(
  { columnKey, title, currentSortConfig, onSort, className }: SortableTableHeaderProps<T>
): React.ReactElement => {
  const isSorted = currentSortConfig.key === columnKey;
  const iconDirection = currentSortConfig.direction === 'ascending' ? 'up' : 'down';
  
  // Heroicon SVGs for sorting arrows
  const SortIcon = () => {
    if (!isSorted) return <svg className="w-4 h-4 text-slate-400 group-hover:text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 9l4-4 4 4m0 6l-4 4-4-4"></path></svg>;
    if (iconDirection === 'up') return <svg className="w-4 h-4 text-sky-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd"></path></svg>;
    return <svg className="w-4 h-4 text-sky-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd"></path></svg>;
  };

  return (
    <th
      scope="col"
      className={`group cursor-pointer select-none transition-colors duration-150 ease-in-out ${className || 'px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider hover:bg-slate-200'}`}
      onClick={() => onSort(columnKey)}
      aria-sort={isSorted ? (currentSortConfig.direction === 'ascending' ? 'ascending' : 'descending') : 'none'}
    >
      <div className="flex items-center space-x-1">
        <span>{title}</span>
        <SortIcon />
      </div>
    </th>
  );
};

export default SortableTableHeader;