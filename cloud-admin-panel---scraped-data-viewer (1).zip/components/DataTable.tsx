
import React, { useState, useMemo } from 'react';
import type { ScrapedItem, SortConfig } from '../types';
import { ITEMS_PER_PAGE } from '../constants';
import Pagination from './Pagination';
import SortableTableHeader from './SortableTableHeader';

interface DataTableProps {
  data: ScrapedItem[];
}

const DataTable: React.FC<DataTableProps> = ({ data }) => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'title', direction: 'ascending' });

  const sortedData = useMemo(() => {
    let sortableItems = [...data];
    if (sortConfig.key !== null) {
      sortableItems.sort((a, b) => {
        // Ensure values exist, provide defaults for sorting if necessary
        const valA = a[sortConfig.key!] ?? (typeof a[sortConfig.key!] === 'string' ? '' : 0);
        const valB = b[sortConfig.key!] ?? (typeof b[sortConfig.key!] === 'string' ? '' : 0);


        if (typeof valA === 'string' && typeof valB === 'string') {
          return sortConfig.direction === 'ascending' ? valA.localeCompare(valB) : valB.localeCompare(valA);
        }
        if (typeof valA === 'number' && typeof valB === 'number') {
          return sortConfig.direction === 'ascending' ? valA - valB : valB - valA;
        }
        // Fallback for mixed types or other types - treat as equal
        return 0;
      });
    }
    return sortableItems;
  }, [data, sortConfig]);

  const currentTableData = useMemo(() => {
    const firstPageIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    const lastPageIndex = firstPageIndex + ITEMS_PER_PAGE;
    return sortedData.slice(firstPageIndex, lastPageIndex);
  }, [currentPage, sortedData]);

  const handleSort = (key: keyof ScrapedItem) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
    setCurrentPage(1); 
  };
  
  if (!data || data.length === 0) {
    // This state might be covered by DashboardPage, but as a fallback:
    return (
      <div className="text-center py-12 bg-white rounded-lg ">
        <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
          <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125V6.375c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v.001A1.125 1.125 0 003.375 7.5z" />
        </svg>
        <h3 className="mt-3 text-lg font-medium text-slate-700">No Data to Display</h3>
        <p className="mt-1 text-sm text-slate-500">
          Try scraping new data or check if there was an error.
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden shadow border border-slate-200 rounded-lg">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200 table-fixed-layout">
          <thead className="bg-slate-100">
            <tr>
              <SortableTableHeader<ScrapedItem> columnKey="title" title="Title" currentSortConfig={sortConfig} onSort={handleSort} className="w-3/12 px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider" />
              <SortableTableHeader<ScrapedItem> columnKey="author" title="Author" currentSortConfig={sortConfig} onSort={handleSort} className="w-2/12 px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider" />
              <SortableTableHeader<ScrapedItem> columnKey="description" title="Description" currentSortConfig={sortConfig} onSort={handleSort} className="w-5/12 px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider" />
              <SortableTableHeader<ScrapedItem> columnKey="year" title="Year" currentSortConfig={sortConfig} onSort={handleSort} className="w-2/12 px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider" />
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-200">
            {currentTableData.map((item, index) => (
              <tr key={item.id} className={`${index % 2 === 0 ? 'bg-white' : 'bg-slate-50'} hover:bg-sky-50 transition-colors duration-150 ease-in-out`}>
                <td className="px-6 py-4 whitespace-normal break-words text-sm font-medium text-slate-900">{item.title}</td>
                <td className="px-6 py-4 whitespace-normal break-words text-sm text-slate-600">{item.author}</td>
                <td className="px-6 py-4 whitespace-normal break-words text-sm text-slate-600 leading-relaxed">{item.description}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600 text-center">{item.year}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {sortedData.length > ITEMS_PER_PAGE && (
        <Pagination
          currentPage={currentPage}
          totalItems={sortedData.length}
          itemsPerPage={ITEMS_PER_PAGE}
          onPageChange={setCurrentPage}
        />
      )}
    </div>
  );
};

export default DataTable;