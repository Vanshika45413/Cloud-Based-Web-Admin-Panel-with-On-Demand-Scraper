
import React, { useState, useEffect, useCallback } from 'react';
import LoginPage from './components/LoginPage';
import DashboardPage from './components/DashboardPage';
import Navbar from './components/Navbar';
import type { User } from './types';
import LoadingSpinner from './components/LoadingSpinner';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loadingAuth, setLoadingAuth] = useState<boolean>(true);

  useEffect(() => {
    // Simulate checking auth status (e.g., from localStorage)
    setTimeout(() => { // Simulate network delay
      const storedUser = localStorage.getItem('dummyUser');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
      setLoadingAuth(false);
    }, 500);
  }, []);

  const handleLogin = useCallback((email: string) => {
    const dummyUser: User = { email, name: email.split('@')[0] || 'Admin User' };
    setUser(dummyUser);
    localStorage.setItem('dummyUser', JSON.stringify(dummyUser));
  }, []);

  const handleLogout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('dummyUser');
  }, []);

  if (loadingAuth) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-slate-100">
        <LoadingSpinner size="lg" color="text-sky-600" />
        <p className="mt-4 text-lg font-medium text-slate-700">Authenticating...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100">
      {user ? (
        <>
          <Navbar user={user} onLogout={handleLogout} />
          <DashboardPage />
        </>
      ) : (
        <LoginPage onLogin={handleLogin} />
      )}
    </div>
  );
};

export default App;