
export const GEMINI_TEXT_MODEL_NAME = 'gemini-2.5-flash-preview-04-17';
export const ITEMS_PER_PAGE = 10;

export const GEMINI_SCRAPE_PROMPT = `Generate a list of 15 unique fictional book records. Each record should include a title, an author (fictional name), a short 1-2 sentence fictional description, and a fictional publication year between 1980 and 2024.
Return the list STRICTLY as a JSON array of objects. Each object must have the following keys: "title" (string), "author" (string), "description" (string), "year" (number).
Do not include any introductory text, explanations, or markdown formatting like \`\`\`json ... \`\`\` around the JSON array itself. The output should be directly parsable as JSON.
Example of a single object:
{
  "title": "The Galactic Cookbook",
  "author": "Zorp Glorbax",
  "description": "A culinary journey through the cosmos, featuring recipes that are out of this world. Learn to prepare nebulous noodles and meteor meatloaf.",
  "year": 2001
}`;
