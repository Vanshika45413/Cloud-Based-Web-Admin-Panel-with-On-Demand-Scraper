
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { ScrapedItem } from '../types';
import { GEMINI_TEXT_MODEL_NAME, GEMINI_SCRAPE_PROMPT } from '../constants';

// Ensure API_KEY is available in the environment.
// In a real deployment, this would be set via build tools or server environment variables.
const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;

if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
  console.warn("API_KEY for Gemini is not configured. Scraping will not work.");
}

// Helper to generate unique IDs (simple version)
const generateId = (): string => Math.random().toString(36).substr(2, 9);

export const fetchScrapedData = async (): Promise<ScrapedItem[]> => {
  if (!ai) {
    throw new Error("Gemini API client is not initialized. Check API_KEY configuration.");
  }

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL_NAME,
      contents: GEMINI_SCRAPE_PROMPT,
      config: {
        responseMimeType: "application/json",
        // For this use case, higher temperature might give more varied fictional data
        temperature: 0.8 
      },
    });

    let jsonStr = response.text.trim();
    
    // Remove potential markdown fences if Gemini adds them despite the prompt
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }

    const parsedData: Omit<ScrapedItem, 'id'>[] = JSON.parse(jsonStr);
    
    if (!Array.isArray(parsedData)) {
        console.error("Parsed data is not an array:", parsedData);
        throw new Error("Gemini API returned data in an unexpected format (not an array).");
    }

    // Add unique IDs to each item
    return parsedData.map(item => ({
      ...item,
      id: generateId(),
      // Ensure year is a number if it comes as string
      year: typeof item.year === 'string' ? parseInt(item.year, 10) : item.year 
    }));

  } catch (error: unknown) {
    console.error("Error fetching or parsing scraped data:", error);
    if (error instanceof Error) {
        // Re-throw GoogleGenAIError specifically if possible for more detailed error handling upstream
        if ((error as any).isGoogleGenAIError) { // Check if it's a GoogleGenAIError instance
            throw error;
        }
        throw new Error(`Failed to process data from Gemini API: ${error.message}`);
    }
    throw new Error("An unknown error occurred while fetching data from Gemini API.");
  }
};
